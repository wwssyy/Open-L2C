Taken from CompCert C 2.4
