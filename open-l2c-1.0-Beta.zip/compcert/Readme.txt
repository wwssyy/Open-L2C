Taken from CompCert C 3.6
