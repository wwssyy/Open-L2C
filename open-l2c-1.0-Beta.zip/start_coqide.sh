# To open .v files each time you click start_coqide.sh (e.g. LsemS.v Ls2LmProof.v), you can add 
# the following commandline to "~/.profile" (Ubuntu) or "~/.bashrc" or "~/.bash_profile" (Redhat):
#
# export COQIDEOPEN="LsemS.v Ls2LmProof.v"
#

FLOCQDIR="compcert/flocq"

INCLUDES="-I src"
INCLUDES=$INCLUDES" -I compcert -I compcert/common -I compcert/lib -I compcert/ia32"
INCLUDES=$INCLUDES" -I "$FLOCQDIR" -I "$FLOCQDIR"/Core -I "$FLOCQDIR"/Prop -I "$FLOCQDIR"/Calc -I "$FLOCQDIR"/Appli"
INCLUDES=$INCLUDES" -I driver -I frontend -I parser"

coqide $INCLUDES
