#! /bin/bash

cd test

rm -fr result
mkdir result

files=`find ./ -iname "*.lustre"`
for f in $files
do
#    name=`echo $f | cut -d'/' -f 3 | cut -d'.' -f 1`;
    dir=`dirname $f`;
    echo $f;
    mkdir -p result/$dir;
    ../l2c -target_dir result/$dir $f;
done

cd ..
