#! /bin/bash

files=`find . -name "*.lustre"`
for f in $files
do
    if [[ $f =~ ^\./([^\.]+)/([^\.]+)\.lustre$ ]]
    then
	echo $f;
	echo ./${BASH_REMATCH[1]};
	../l2c -target_dir ./${BASH_REMATCH[1]} $f;
    else
	echo "Not propper format";
    fi
done
