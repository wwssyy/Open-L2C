import os
import argparse
import random

# python3 test.py --lustre minus.lustre --input auto --cycle_times 10 --var_range 100
# python3 test.py --lustre minus.lustre --input manual

def generate_c_file(lustre, in_var_arr, out_var_arr):

    c_file = lustre.split(".")[0] + ".c"
    node_name = lustre.split(".")[0]

    os.system("l2c " + lustre)

    with open(c_file, 'r+') as f:
        content = f.read()
        f.seek(0, 0)
        f.write("#include <stdio.h>\n" + "#include <stdlib.h>\n\n" + content)

    with open(c_file, 'a') as f:
        f.write("int main()\n{\n" +
                "  inC_" + node_name + " inC;\n" +
                "  outC_" + node_name + " outC;\n" +
                "  " + node_name + "_reset(&outC);\n")

        cycle_times = 0
        in_var_value_arr = []
        for i in in_var_arr:
            in_var_value_arr.append([])
        with open("input.txt",'r') as input_file:
            for line in input_file:
                if line.startswith("#") or line == "\n":
                    continue
                cur_value_arr = line.replace("\n", "").split(" ")
                for i in range(len(in_var_arr)):
                    in_var_value_arr[i].append(cur_value_arr[i])
                cycle_times += 1

        for i in range(len(in_var_arr)):
            if in_var_arr[i]["type"] != "real":
                f.write("  int " + in_var_arr[i]["name"] + "[" + str(cycle_times) +"] = { " + ", ".join(in_var_value_arr[i]) + " };\n")
            else:
                f.write("  double " + in_var_arr[i]["name"] + "[" + str(cycle_times) +"] = { " + ", ".join(in_var_value_arr[i]) + " };\n")

        f.write("  int i = 0;\n" +
                "  for (; i < " + str(cycle_times) + "; i++) {\n")
        for i in in_var_arr:
            if i["type"] != "real":
                f.write("    inC." + i["name"] + " = " + i["name"] + "[i];\n")
                f.write('    printf("%d ", inC.' + i["name"] + ");\n")
            else:
                f.write("    inC." + i["name"] + " = " + i["name"] + "[i];\n")
                f.write('    printf("%f ", inC.' + i["name"] + ");\n")
        f.write("    " + node_name + "(&inC, &outC);\n")
        for i in out_var_arr:
            if i["type"] != "real":
                f.write('    printf("%d ", outC.' + i["name"] + ");\n")
            else:
                f.write('    printf("%f ", outC.' + i["name"] + ");\n")
        f.write('    printf("\\n");\n')
        f.write('  }\n')
        f.write('  return 0;\n')
        f.write('}\n')


def main():
    parser = argparse.ArgumentParser(description='manual to this script')
    parser.add_argument('--lustre', type=str, default=None)
    parser.add_argument('--input', type=str, default="auto")
    parser.add_argument('--cycle_times', type=int, default=10)
    parser.add_argument('--var_range', type=int, default=100)
    args = parser.parse_args()

    lustre = args.lustre
    cycle_times = args.cycle_times
    var_range = args.var_range

    # 解析获得输入输出参数列表
    main_node_line = ""
    with open(lustre, 'r') as f:
        for line in f:
            if line.startswith("node "):
                main_node_line = line

    in_var_arr = []
    for i in main_node_line[main_node_line.index("(") + 1: main_node_line.index(")")].split(";"):
        in_var_arr.append({"name": i.split(":")[0], "type": i.split(":")[1]})

    out_var_arr = []
    for i in main_node_line[main_node_line.rindex("(") + 1: main_node_line.rindex(")")].split(";"):
        out_var_arr.append({"name": i.split(":")[0], "type": i.split(":")[1]})

    # 产生手动输入文件，将输入参数名称和类型写入 input.txt
    if args.input == "manual" and not os.path.exists("input.txt"):
        with open("input.txt", "w") as f:
            for var in in_var_arr:
                f.write("# " + var["name"] + " : " + var["type"] + "\n")
        return
    
    # 产生自动输入文件
    elif args.input == "auto":
        with open("input.txt", 'w') as f:
            for _ in range(cycle_times):
                in_var_list = []
                var_range_dict = {"int": var_range, "bool": 1, "char": 127}
                for j in in_var_arr:
                    if j["type"] != "real":
                        in_var_list.append(str(random.randint(0, var_range_dict[j["type"]])))
                    else:
                        in_var_list.append(str(random.uniform(0, var_range)))
                f.write(" ".join(in_var_list) + "\n")

    generate_c_file(lustre, in_var_arr, out_var_arr)

    os.system("gcc " + lustre.split(".")[0] + ".c" + " -o gcc_out")
    os.system("ccomp " + lustre.split(".")[0] + ".c" + " -o ccomp_out")
    os.system("./gcc_out > gcc_output.txt")
    os.system("./ccomp_out > ccomp_output.txt")

    print("gcc output:")
    gcc_output = ""
    with open("gcc_output.txt", 'r') as f:
        gcc_output = f.read()
        print(gcc_output)

    print("ccomp output:")
    ccomp_output = ""
    with open("ccomp_output.txt", 'r') as f:
        ccomp_output = f.read()
        print(ccomp_output)

    if gcc_output == ccomp_output:
        print("the output of gcc and ccomp are same.")
    else:
        print("the output of gcc and ccomp are different.")

    os.system("rm input.txt")
    os.system("rm " + lustre.split(".")[0] + ".c")
    os.system("rm gcc_out")
    os.system("rm ccomp_out")
    os.system("rm gcc_output.txt")
    os.system("rm ccomp_output.txt")


if __name__ == "__main__":
    main()
