#!/bin/bash
#statistic scripts

echo " "
echo "L2C Compiler Source Code Statistic on `date +%Y%m%d`"
echo "* Section 1: Summary "
echo -n "  ** Total lines of coq code               :" 
find . -name '*.v' | xargs grep -v '^$' | wc -l
echo -n "  ** Total lines of ocaml code             : " 
find . -name '*.ml' | xargs grep -v '^$' | wc -l
echo -n "  ***Our developed coq code                :" 
ls ./extraction/*.v src/*.v driver/*.v parser/*.v parser/*.vy  | xargs grep -v '^$' | wc -l
echo -n "  ***Our developed ml code                 : " 
ls ./driver/*.ml ./src/*.ml parser/*.ml* frontend/*.ml* compcert/PrintClight.ml | xargs grep -v '^$' | wc -l
echo -n "  ***Total lines from Compcert (*.v code)  :"
find ./compcert/  -name '*.v' | xargs grep -v '^$' | wc -l
echo -n "  ***Total lines from Compcert (*.ml code) :  "
find ./compcert/lib/ ./compcert/common/ ./compcert/flocq/ -name '*.ml' | xargs grep -v '^$' | wc -l

echo " "
echo -n "  ** Total number of l2c definitions       :  "
ls ./extraction/*.v src/*.v driver/*.v parser/*.v parser/*.vy | xargs grep -E '(Definition|Fixpoint|Inductive)' | wc -l
echo -n "  ** Total number of l2c lemmas/theorems   :  "
ls ./extraction/*.v src/*.v driver/*.v parser/*.v parser/*.vy | xargs grep -E '(Lemma|Theorem)' | wc -l
echo -n "  ** Total number of admitted lemmas       :  "
ls ./extraction/*.v src/*.v driver/*.v parser/*.v parser/*.vy | xargs grep -E 'admit' | wc -l

echo " "
echo "* Section 2: Work Breakdown Structure "
echo -n "  ** Lustre syntax and semantics (*.v code): " 
cd src
listsyntax="ls Lustre.v LustreW.v LustreV.v LustreS.v LustreR.v LustreF.v Lsem*.v Lint.v Lident.v Lvalues.v Lenv*.v Ltypes.v Lop.v Ctemp.v Csem.v Cltypes.v Clop.v"
$listsyntax | xargs grep -v '^$' | wc -l
echo -n "  *** definitions       :  "
$listsyntax | xargs grep -E '(Definition|Fixpoint|Inductive)' | wc -l
echo -n "  *** lemmas/theorems   :  "
$listsyntax | xargs grep -E '(Lemma|Theorem)' | wc -l
echo -n "  *** admitted lemmas   :  "
$listsyntax | xargs grep -E 'admit' | wc -l

echo -n "  ** Lustre translate (*.v code): "
listtranslate="ls ../extraction/extraction.v TransTypeName.v LustreWGen.v LustreVGen.v LustreSGen.v SimplConstblock.v Toposort.v SimplLustreS.v LustreRGen.v TransMainArgs.v TransTypecmp.v LustreFGen.v MergeIfelseMore.v OutstructGen.v ClassifyRetsVar.v ResetfuncGen.v SimplEnv.v ClassifyArgsVar.v CtempGen.v ClightGen.v" 
$listtranslate | xargs grep -v '^$' | wc -l
echo -n "  *** definitions       :  "
$listtranslate | xargs grep -E '(Definition|Fixpoint|Inductive)' | wc -l
echo -n "  *** lemmas/theorems   :  "
$listtranslate | xargs grep -E '(Lemma|Theorem)' | wc -l
echo -n "  *** admitted lemmas   :  "
$listtranslate | xargs grep -E 'admit' | wc -l


echo -n "  ** Lustre translate proof (*.v code): " 
listproof="ls *Proof.v ExtraList.v ../driver/Compiler.v"
$listproof | xargs grep -v '^$' | wc -l
echo -n "  *** definitions       :  "
$listproof | xargs grep -E '(Definition|Fixpoint|Inductive)' | wc -l
echo -n "  *** lemmas/theorems   :  "
$listproof | xargs grep -E '(Lemma|Theorem)' | wc -l
echo -n "  *** admitted lemmas   :  "
$listproof | xargs grep -E 'admit' | wc -l

echo -n "  ** Lustre translation (*.ml code): " 
cd ..
cd extraction
ls TransTypeName.ml LustreWGen.ml LustreVGen.ml LustreSGen.ml SimplConstblock.ml Toposort.ml SimplLustreS.ml LustreRGen.ml TransMainArgs.ml TransTypecmp.ml LustreFGen.ml MergeIfelseMore.ml OutstructGen.ml ClassifyRetsVar.ml ResetfuncGen.ml SimplEnv.ml ClassifyArgsVar.ml CtempGen.ml ClightGen.ml  | xargs grep -v '^$' | wc -l


echo -n "  **Validated Lustre translation  (*.ml code): " 
cd ..
cd extraction
ls LustreSGen.ml SimplConstblock.ml Toposort.ml SimplLustreS.ml LustreRGen.ml TransMainArgs.ml TransTypecmp.ml LustreFGen.ml MergeIfelseMore.ml OutstructGen.ml ClassifyRetsVar.ml ResetfuncGen.ml SimplEnv.ml ClassifyArgsVar.ml CtempGen.ml ClightGen.ml  | xargs grep -v '^$' | wc -l
