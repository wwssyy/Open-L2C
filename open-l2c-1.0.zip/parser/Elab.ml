(************************************************************************)
(*                                                                     *)
(*                     The L2C verified compiler                       *)
(*                                                                     *)
(*                   L2C Group, Tsinghua University                    *)
(*                                                                     *)
(*  Copyright Tsinghua University. All rights reserved. This file is   *) 
(*  distributed under the terms of the GNU General Public License as   *)
(*  published by the Free Software Foundation, either version 2 of the *)
(*  License, or (at your option) any later version.  This file is also *)
(*  distributed both under the term of the Tsinghua Non-Commercial     *)
(*  License Agreement for the L2C verified compiler and under the term *)
(*  of the INRIA Non-Commercial License Agreement for the CompCert     *)
(*  verified compiler.                                                 *)
(*                                                                     *)
(* **********************************************************************)

open Tree
open Camlcoq
open! Floats

let z_of_str str fst =
  let res = ref Z.Z0 in
  let base = 10 in
  for i = fst to String.length str - 1 do
    let d = int_of_char str.[i] in
    let d = d - int_of_char '0' in
    assert (d >= 0 && d < base);
    res := Z.add (Z.mul (Z.of_uint base) !res) (Z.of_uint d)
  done;
  !res

let convertFloat f =
  let mant = z_of_str (f.intPart ^ f.fracPart) 0 in
  match mant with
    | Z.Z0 -> Float.to_single Float.zero
    | Z.Zpos mant ->

      let sgExp = match f.expPart.[0] with '+' | '-' -> true | _ -> false in
      let exp = z_of_str f.expPart (if sgExp then 1 else 0) in
      let exp = if f.expPart.[0] = '-' then Z.neg exp else exp in
      let shift_exp = String.length f.fracPart in
      let exp = Z.sub exp (Z.of_uint shift_exp) in

      let base = P.of_int 10 in
      Float32.from_parsed base mant exp

    | Z.Zneg _ -> assert false

let convertReal f =
  let mant = z_of_str (f.intPart ^ f.fracPart) 0 in
  match mant with
    | Z.Z0 -> Float.zero
    | Z.Zpos mant ->

      let sgExp = match f.expPart.[0] with '+' | '-' -> true | _ -> false in
      let exp = z_of_str f.expPart (if sgExp then 1 else 0) in
      let exp = if f.expPart.[0] = '-' then Z.neg exp else exp in
      let shift_exp = String.length f.fracPart in
      let exp = Z.sub exp (Z.of_uint shift_exp) in

      let base = P.of_int 10 in

      Float.from_parsed base mant exp

    | Z.Zneg _ -> assert false
